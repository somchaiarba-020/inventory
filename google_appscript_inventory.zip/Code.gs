/**
 * ระบบเบิกจ่ายพัสดุออนไลน์ (NT Supply & Inventory Requisition System)
 * สำหรับ Google Apps Script + Google Sheets
 *
 * วิธีติดตั้งและเปิดสิทธิ์ส่งอีเมล:
 * 1. สร้างไฟล์ Google Sheets ใหม่ (หรือใช้ไฟล์เดิม)
 * 2. ไปที่เมนู ส่วนขยาย (Extensions) > Apps Script
 * 3. วางโค้ดนี้ในไฟล์ Code.gs และสร้างไฟล์ HTML ชื่อ Index.html แล้ววางโค้ดหน้าเว็บลงไป
 * 4. เลือกฟังก์ชัน setupDatabase ด้านบน แล้วกดปุ่ม "เรียกใช้" (Run) 1 ครั้ง
 *    (ระบบจะขออนุญาตสิทธิ์ Google Sheets และสิทธิ์ส่งอีเมล MailApp ให้กด Allow / อนุญาต)
 * 5. กดปุ่ม "ทำให้ใช้งานได้" (Deploy) > "การทำให้ใช้งานได้รายการใหม่" (New deployment) > เลือกประเภท "เว็บแอป" (Web app)
 *    - ดำเนินการในฐานะ (Execute as): ตนเอง (Me)
 *    - ผู้ที่มีสิทธิ์เข้าถึง (Who has access): ทุกคน (Anyone)
 */

const SHEET_NAMES = {
  USERS: 'Users',
  INVENTORY: 'Inventory',
  REQUISITIONS: 'Requisitions',
  LOGS: 'StockLogs',
  CATEGORIES: 'Categories'
};

const DEFAULT_CATEGORIES_LIST = [
  'วัสดุสำนักงาน',
  'วัสดุคอมพิวเตอร์',
  'วัสดุงานบ้านงานครัว',
  'วัสดุไฟฟ้าและวิทยุ',
  'วัสดุศูนย์การขาย',
  'วัสดุศูนย์วิศวกรรม',
  'อื่นๆ'
];

const SUPER_ADMIN_CONFIG = {
  userId: 'USR-000',
  username: 'สมชาย อาบา',
  password: '123456',
  fullName: 'สมชาย อาบา',
  department: 'บตน.2(ยล.)',
  role: 'super_admin',
  position: 'ผจ.ขบตน.2(ยล.)',
  email: 'somchaiarba@gmail.com',
  active: true
};

function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('ระบบเบิกจ่ายพัสดุออนไลน์ | NT e-Inventory System')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * ฟังก์ชันช่วยตรวจสอบและอัปเกรดตาราง Users อัตโนมัติ (รองรับทั้งชีตใหม่และชีตเดิมที่เคยสร้างไว้แล้ว)
 * พร้อมเพิ่มบัญชี Super Admin (สมชาย อาบา) ลงในตารางเสมอ
 */
function ensureSuperAdminAndSchema(ss, now) {
  let userSheet = ss.getSheetByName(SHEET_NAMES.USERS);
  if (!userSheet) {
    userSheet = ss.insertSheet(SHEET_NAMES.USERS);
    userSheet.appendRow(['UserID', 'Username', 'Password', 'FullName', 'Department', 'Role', 'Position', 'Email', 'Active', 'CreatedAt']);
    userSheet.getRange(1, 1, 1, 10).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');
    const initialUsers = [
      [SUPER_ADMIN_CONFIG.userId, SUPER_ADMIN_CONFIG.username, SUPER_ADMIN_CONFIG.password, SUPER_ADMIN_CONFIG.fullName, SUPER_ADMIN_CONFIG.department, SUPER_ADMIN_CONFIG.role, SUPER_ADMIN_CONFIG.position, SUPER_ADMIN_CONFIG.email, 'TRUE', now],
      ['USR-001', 'admin', '1234', 'กิตติพงศ์ วงศ์สุวรรณ', 'ฝ่ายพัสดุและคลังสินค้า', 'admin', 'หัวหน้าเจ้าหน้าที่พัสดุ', 'kittipong.w@ntplc.co.th', 'TRUE', now],
      ['USR-002', 'staff01', '1234', 'พิมพ์ชนก รัตนโชติ', 'ฝ่ายบริหารทั่วไป', 'staff', 'นักวิชาการบริหารงานทั่วไป', 'pimchanok.r@ntplc.co.th', 'TRUE', now],
      ['USR-003', 'staff02', '1234', 'ณัฐวุฒิ ศรีสวัสดิ์', 'ฝ่ายเทคโนโลยีสารสนเทศ', 'staff', 'วิศวกรโทรคมนาคม', 'nattawut.s@ntplc.co.th', 'TRUE', now]
    ];
    userSheet.getRange(2, 1, initialUsers.length, 10).setValues(initialUsers);
    return userSheet;
  }

  // กรณีมีตาราง Users อยู่แล้ว ตรวจสอบว่ามีคอลัมน์ Email หรือยัง (อัปเกรดจาก 9 คอลัมน์เป็น 10 คอลัมน์อัตโนมัติ)
  const data = userSheet.getDataRange().getValues();
  if (data.length > 0 && String(data[0][7]).trim() !== 'Email') {
    userSheet.getRange(1, 1, 1, 10).setValues([['UserID', 'Username', 'Password', 'FullName', 'Department', 'Role', 'Position', 'Email', 'Active', 'CreatedAt']]);
    userSheet.getRange(1, 1, 1, 10).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');
    for (let i = 1; i < data.length; i++) {
      const oldActive = String(data[i][7] !== undefined ? data[i][7] : 'TRUE');
      const oldCreated = String(data[i][8] || now);
      userSheet.getRange(i + 1, 8, 1, 3).setValues([['', oldActive, oldCreated]]);
    }
  }

  // ตรวจสอบว่ามีบัญชี Super Admin (สมชาย อาบา) ในชีตหรือยัง ถ้ายังไม่มีให้เพิ่มอัตโนมัติ
  const updatedData = userSheet.getDataRange().getValues();
  let foundSuperAdminRow = -1;
  for (let i = 1; i < updatedData.length; i++) {
    const rUser = String(updatedData[i][1] || '').trim().toLowerCase();
    const rName = String(updatedData[i][3] || '').trim().toLowerCase();
    const rEmail = String(updatedData[i][7] || '').trim().toLowerCase();
    const rRole = String(updatedData[i][5] || '').trim().toLowerCase();
    if (rRole === 'super_admin' || rName === 'สมชาย อาบา' || rEmail === 'somchaiarba@gmail.com' || rEmail === 'somchaiarb@gmail.com' || rUser === 'สมชาย อาบา') {
      foundSuperAdminRow = i + 1;
      break;
    }
  }

  const superRowValues = [
    SUPER_ADMIN_CONFIG.userId,
    SUPER_ADMIN_CONFIG.username,
    SUPER_ADMIN_CONFIG.password,
    SUPER_ADMIN_CONFIG.fullName,
    SUPER_ADMIN_CONFIG.department,
    SUPER_ADMIN_CONFIG.role,
    SUPER_ADMIN_CONFIG.position,
    SUPER_ADMIN_CONFIG.email,
    'TRUE',
    now
  ];

  if (foundSuperAdminRow === -1) {
    userSheet.appendRow(superRowValues);
  }

  return userSheet;
}

/**
 * ฟังก์ชันส่งอีเมลแจ้งข้อมูลบัญชีและรหัสผ่าน (รองรับทั้ง MailApp และ GmailApp)
 */
function sendAccountEmailNotification(userObj, rawPassword, isSuperAdminNotice, isTempReset) {
  const targetEmail = String(userObj.email || '').trim();
  if (!targetEmail) {
    return { sent: false, error: 'ไม่ได้ระบุอีเมล' };
  }

  const roleLabel = userObj.role === 'super_admin'
    ? 'Super Admin (ผู้ดูแลระบบสูงสุด)'
    : userObj.role === 'admin'
      ? 'Admin (เจ้าหน้าที่พัสดุ)'
      : 'Staff (ผู้เบิกพัสดุ)';

  const subject = isTempReset
    ? '[NT e-Inventory] แจ้งรหัสผ่านชั่วคราว (ลืมรหัสผ่าน) ระบบเบิกจ่ายพัสดุออนไลน์'
    : isSuperAdminNotice
      ? '[NT e-Inventory] ยืนยันสิทธิ์ Super Admin ระบบเบิกจ่ายพัสดุออนไลน์ (' + userObj.fullName + ')'
      : '[NT e-Inventory] แจ้งรหัสผ่านและยืนยันการสมัครใช้งานระบบเบิกจ่ายพัสดุออนไลน์';

  const introLine = isTempReset
    ? 'ตามที่คุณได้แจ้งลืมรหัสผ่าน ระบบได้ออก <strong>รหัสผ่านชั่วคราว (Temporary Password)</strong> สำหรับเข้าใช้งานระบบเบิกจ่ายพัสดุออนไลน์เรียบร้อยแล้ว รายละเอียดดังนี้:'
    : 'ระบบได้ยืนยันบัญชีผู้ใช้งานและรหัสผ่านสำหรับเข้าใช้งานระบบเบิกจ่ายพัสดุออนไลน์เรียบร้อยแล้ว รายละเอียดดังนี้:';

  const htmlBody = ''
    + '<div style="font-family: Sarabun, Tahoma, sans-serif; max-width: 580px; margin: 0 auto; border: 1px solid #e2e8f0; border-top: 6px solid #FFD100; border-radius: 12px; padding: 24px; color: #334155; background: #ffffff;">'
    + '<h2 style="color: #555859; margin-top: 0;">ระบบเบิกจ่ายพัสดุออนไลน์ (NT e-Inventory)</h2>'
    + '<p>เรียน คุณ <strong>' + userObj.fullName + '</strong>,</p>'
    + '<p>' + introLine + '</p>'
    + '<div style="background: #FFFBEB; border: 1px solid #FFD100; border-radius: 10px; padding: 16px; margin: 16px 0; line-height: 1.7;">'
    + '<div><strong>ชื่อ-นามสกุล:</strong> ' + userObj.fullName + '</div>'
    + '<div><strong>ชื่อผู้ใช้งาน (Username สำหรับล็อกอิน):</strong> ' + userObj.username + ' (หรือใช้อีเมล ' + targetEmail + ')</div>'
    + '<div><strong>' + (isTempReset ? 'รหัสผ่านชั่วคราว (Temporary Password):' : 'รหัสผ่าน (Password):') + '</strong> <span style="color: #e11d48; font-weight: bold;">' + rawPassword + '</span></div>'
    + '<div><strong>ส่วนงาน/ฝ่าย:</strong> ' + userObj.department + '</div>'
    + '<div><strong>ตำแหน่ง:</strong> ' + (userObj.position || '-') + '</div>'
    + '<div><strong>อีเมล:</strong> ' + targetEmail + '</div>'
    + '<div><strong>สิทธิ์การใช้งาน:</strong> ' + roleLabel + '</div>'
    + '</div>'
    + '</div>';

  try {
    MailApp.sendEmail({
      to: targetEmail,
      subject: subject,
      htmlBody: htmlBody
    });
    return { sent: true, error: '' };
  } catch (err1) {
    try {
      GmailApp.sendEmail(targetEmail, subject, '', { htmlBody: htmlBody });
      return { sent: true, error: '' };
    } catch (err2) {
      return { sent: false, error: String(err2 || err1) };
    }
  }
}

/**
 * ลืมรหัสผ่าน (Forgot Password): ค้นหาผู้ใช้งานจาก Email ที่เคยสมัคร สร้างรหัสผ่านชั่วคราว และส่งทาง Email
 */
function requestTemporaryPassword(emailInput) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const cleanEmail = String(emailInput || '').trim().toLowerCase();
    if (!cleanEmail) {
      return { success: false, message: 'กรุณากรอกอีเมลที่ใช้สมัครใช้งาน' };
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
    const sheet = ensureSuperAdminAndSchema(ss, nowStr);
    const data = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      const rowEmail = String(data[i][7] || '').trim().toLowerCase();
      if (rowEmail && rowEmail === cleanEmail) {
        const tempPass = 'NT' + String(Math.floor(100000 + Math.random() * 900000));
        sheet.getRange(i + 1, 3).setValue(tempPass);

        const userObj = {
          userId: String(data[i][0]),
          username: String(data[i][1]),
          fullName: String(data[i][3]),
          department: String(data[i][4]),
          role: String(data[i][5]).toLowerCase(),
          position: String(data[i][6] || ''),
          email: String(data[i][7] || '')
        };

        const mailRes = sendAccountEmailNotification(userObj, tempPass, false, true);
        return {
          success: true,
          emailSent: mailRes.sent,
          tempPassword: tempPass,
          user: userObj,
          message: mailRes.sent
            ? 'ระบบได้ส่งรหัสผ่านชั่วคราวไปยังอีเมล ' + userObj.email + ' เรียบร้อยแล้ว'
            : 'ออกรหัสผ่านชั่วคราวเรียบร้อยแล้ว'
        };
      }
    }

    return { success: false, message: 'ไม่พบอีเมล "' + emailInput + '" ในระบบ กรุณาตรวจสอบอีเมลที่เคยสมัครใช้งาน' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * รันฟังก์ชันนี้ 1 ครั้งเพื่อสร้าง/อัปเดตตารางใน Google Sheets
 */
function setupDatabase() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const now = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');

  // 1. สร้างหรืออัปเกรดตารางผู้ใช้งาน (Users) พร้อมเพิ่ม Super Admin (สมชาย อาบา)
  ensureSuperAdminAndSchema(ss, now);

  // 2. ตารางหมวดหมู่พัสดุ (Categories)
  let catSheet = ss.getSheetByName(SHEET_NAMES.CATEGORIES);
  if (!catSheet) {
    catSheet = ss.insertSheet(SHEET_NAMES.CATEGORIES);
    catSheet.appendRow(['CategoryName', 'UpdatedAt']);
    catSheet.getRange(1, 1, 1, 2).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');
    const catRows = DEFAULT_CATEGORIES_LIST.map(function(c) { return [c, now]; });
    catSheet.getRange(2, 1, catRows.length, 2).setValues(catRows);
  }

  // 3. ตารางรายการพัสดุ (Inventory)
  let invSheet = ss.getSheetByName(SHEET_NAMES.INVENTORY);
  if (!invSheet) {
    invSheet = ss.insertSheet(SHEET_NAMES.INVENTORY);
    invSheet.appendRow(['ItemCode', 'Name', 'Category', 'Unit', 'Stock', 'MinStock', 'UnitPrice', 'Location', 'UpdatedAt', 'ImagesJSON', 'PrimaryImageIdx']);
    invSheet.getRange(1, 1, 1, 11).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');
    const initialItems = [
      ['INV-1001', 'กระดาษถ่ายเอกสาร A4 80 แกรม (Double A)', 'วัสดุสำนักงาน', 'รีม', 85, 20, 125, 'ชั้น A-01', now, '[]', 0],
      ['INV-1002', 'ปากกาลูกลื่นหมึกน้ำเงิน 0.5 มม. (แพ็ก 12 ด้าม)', 'วัสดุสำนักงาน', 'แพ็ก', 42, 15, 95, 'ชั้น A-02', now, '[]', 0],
      ['INV-1003', 'แฟ้มสันกว้าง 3 นิ้ว ตราช้าง', 'วัสดุสำนักงาน', 'แฟ้ม', 16, 20, 68, 'ชั้น A-04', now, '[]', 0],
      ['INV-2001', 'ตลับหมึกเลเซอร์ HP 85A (CE285A) แท้', 'วัสดุคอมพิวเตอร์', 'กล่อง', 6, 8, 1890, 'ตู้ C-01', now, '[]', 0],
      ['INV-2002', 'เมาส์ไร้สาย Logitech M331 Silent Plus', 'วัสดุคอมพิวเตอร์', 'ชิ้น', 14, 5, 590, 'ตู้ C-02', now, '[]', 0],
      ['INV-2003', 'แฟลชไดรฟ์ Kingston DataTraveler 64GB USB 3.2', 'วัสดุคอมพิวเตอร์', 'ชิ้น', 4, 10, 195, 'ตู้ C-03', now, '[]', 0],
      ['INV-3001', 'น้ำยาทำความสะอาดพื้น 3.8 ลิตร', 'วัสดุงานบ้านงานครัว', 'แกลลอน', 22, 8, 180, 'ห้องพัสดุ B-01', now, '[]', 0],
      ['INV-3002', 'กระดาษชำระม้วนใหญ่ JRT (แพ็ก 12 ม้วน)', 'วัสดุงานบ้านงานครัว', 'แพ็ก', 8, 10, 420, 'ห้องพัสดุ B-02', now, '[]', 0],
      ['INV-4001', 'หลอดไฟ LED T8 18W Daylight Philips', 'วัสดุไฟฟ้าและวิทยุ', 'หลอด', 30, 10, 145, 'ชั้น E-01', now, '[]', 0],
      ['INV-5001', 'ชุดเอกสารใบสมัครและโบรชัวร์โปรโมชัน NT Broadband', 'วัสดุศูนย์การขาย', 'แพ็ก', 40, 10, 250, 'ชั้น S-01', now, '[]', 0],
      ['INV-6001', 'หัวต่อไฟเบอร์ออปติก Fast Connector SC/APC', 'วัสดุศูนย์วิศวกรรม', 'กล่อง', 35, 10, 450, 'ชั้น ENG-01', now, '[]', 0],
      ['INV-7001', 'สายไฟเบอร์ออปติก Patch Cord SC-APC 3 เมตร', 'อื่นๆ', 'เส้น', 25, 10, 160, 'ชั้น F-01', now, '[]', 0]
    ];
    invSheet.getRange(2, 1, initialItems.length, 11).setValues(initialItems);
  }

  // 4. ตารางใบเบิกพัสดุ (Requisitions)
  let reqSheet = ss.getSheetByName(SHEET_NAMES.REQUISITIONS);
  if (!reqSheet) {
    reqSheet = ss.insertSheet(SHEET_NAMES.REQUISITIONS);
    reqSheet.appendRow([
      'ReqID', 'CreatedAt', 'Username', 'RequesterName', 'Department',
      'Purpose', 'Priority', 'ItemsJSON', 'TotalQty', 'TotalValue',
      'Status', 'ApprovedBy', 'ActionAt', 'AdminNote'
    ]);
    reqSheet.getRange(1, 1, 1, 14).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');
  }

  // 5. ตารางประวัติเคลื่อนไหวสต็อก (StockLogs)
  let logSheet = ss.getSheetByName(SHEET_NAMES.LOGS);
  if (!logSheet) {
    logSheet = ss.insertSheet(SHEET_NAMES.LOGS);
    logSheet.appendRow(['LogID', 'Timestamp', 'ItemCode', 'ItemName', 'ActionType', 'ChangeQty', 'RemainStock', 'ActorName', 'Reference']);
    logSheet.getRange(1, 1, 1, 9).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');
  }

  return { success: true, message: 'ตั้งค่าฐานข้อมูล Google Sheets และบัญชี Super Admin (สมชาย อาบา) เรียบร้อยแล้ว' };
}

/**
 * ฟังก์ชันสำหรับกด Run ใน Apps Script Editor เพื่อทดสอบส่งอีเมลยืนยันไปยัง somchaiarba@gmail.com โดยตรง
 */
function sendSuperAdminConfirmationEmail() {
  return sendAccountEmailNotification(SUPER_ADMIN_CONFIG, SUPER_ADMIN_CONFIG.password, true, false);
}

/**
 * ตรวจสอบการเข้าสู่ระบบ (Login) - รองรับ Super Admin (สมชาย อาบา / somchaiarba@gmail.com / 123456) เสมอ
 */
function authenticateUser(username, password) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const now = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
  const sheet = ensureSuperAdminAndSchema(ss, now);

  const cleanInput = String(username || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const cleanPass = String(password || '').trim();

  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const rowUser = String(row[1] || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const rowPass = String(row[2] || '').trim();
    const rowFullName = String(row[3] || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const rowEmail = String(row[7] || '').trim().toLowerCase();
    const isActive = String(row[8] !== undefined ? row[8] : 'TRUE').toUpperCase() !== 'FALSE';

    if ((rowUser === cleanInput || rowFullName === cleanInput || (rowEmail && rowEmail === cleanInput)) && rowPass === cleanPass) {
      if (!isActive) {
        return { success: false, message: 'บัญชีผู้ใช้นี้ถูกระงับการใช้งาน กรุณาติดต่อผู้ดูแลระบบ' };
      }
      return {
        success: true,
        user: {
          userId: String(row[0]),
          username: String(row[1]),
          fullName: String(row[3]),
          department: String(row[4]),
          role: String(row[5]).toLowerCase(),
          position: String(row[6] || ''),
          email: String(row[7] || ''),
          active: isActive
        }
      };
    }
  }

  if (
    (cleanInput === 'สมชาย อาบา' || cleanInput === 'somchaiarba@gmail.com' || cleanInput === 'somchai') &&
    cleanPass === '123456'
  ) {
    return {
      success: true,
      user: SUPER_ADMIN_CONFIG
    };
  }

  return { success: false, message: 'ชื่อผู้ใช้/อีเมล หรือรหัสผ่านไม่ถูกต้อง' };
}

/**
 * สมัครสมาชิกใหม่ (ได้รับสิทธิ์เป็น staff เท่านั้น ยกเว้นข้อมูลของ Super Admin สมชาย อาบา) พร้อมส่งรหัสผ่านทาง Email
 */
function registerNewUser(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
    const sheet = ensureSuperAdminAndSchema(ss, nowStr);
    const data = sheet.getDataRange().getValues();

    const cleanUser = String(payload.username || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const cleanName = String(payload.fullName || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const cleanEmail = String(payload.email || '').trim().toLowerCase();
    const rawPass = String(payload.password || '').trim();

    if (cleanName === 'สมชาย อาบา' || cleanEmail === 'somchaiarba@gmail.com' || cleanUser === 'สมชาย อาบา') {
      const mailRes = sendAccountEmailNotification(SUPER_ADMIN_CONFIG, SUPER_ADMIN_CONFIG.password, true, false);
      return {
        success: true,
        emailSent: mailRes.sent,
        emailError: mailRes.error,
        message: mailRes.sent
          ? 'ยืนยันบัญชี Super Admin (สมชาย อาบา) และส่งรหัสผ่านไปยังอีเมล ' + SUPER_ADMIN_CONFIG.email + ' เรียบร้อยแล้ว'
          : 'ยืนยันบัญชี Super Admin (สมชาย อาบา) เรียบร้อยแล้ว',
        user: SUPER_ADMIN_CONFIG
      };
    }

    for (let i = 1; i < data.length; i++) {
      if (String(data[i][1] || '').replace(/\s+/g, ' ').trim().toLowerCase() === cleanUser) {
        return { success: false, message: 'ชื่อผู้ใช้งาน "' + payload.username + '" มีในระบบแล้ว กรุณาใช้ชื่ออื่น' };
      }
      if (cleanEmail && String(data[i][7] || '').trim().toLowerCase() === cleanEmail) {
        return { success: false, message: 'อีเมล "' + payload.email + '" ถูกลงทะเบียนไว้แล้วในระบบ' };
      }
    }

    const nextId = 'USR-' + String(sheet.getLastRow()).padStart(3, '0');
    const userEmail = String(payload.email || '').trim();
    const newUserObj = {
      userId: nextId,
      username: String(payload.username).trim(),
      fullName: String(payload.fullName).trim(),
      department: String(payload.department).trim(),
      role: 'staff',
      position: String(payload.position || 'พนักงาน').trim(),
      email: userEmail,
      active: true,
      createdAt: nowStr
    };

    sheet.appendRow([
      newUserObj.userId,
      newUserObj.username,
      rawPass,
      newUserObj.fullName,
      newUserObj.department,
      'staff',
      newUserObj.position,
      newUserObj.email,
      'TRUE',
      nowStr
    ]);

    const mailRes = sendAccountEmailNotification(newUserObj, rawPass, false, false);

    return {
      success: true,
      emailSent: mailRes.sent,
      emailError: mailRes.error,
      message: mailRes.sent
        ? 'สมัครใช้งานสำเร็จ! ระบบได้ส่งรหัสผ่านไปยังอีเมล ' + userEmail + ' เรียบร้อยแล้ว'
        : 'สมัครใช้งานสำเร็จ! (หมายเหตุ: กรุณากด Run ฟังก์ชัน setupDatabase หรือ sendSuperAdminConfirmationEmail ใน Apps Script เพื่ออนุญาตสิทธิ์ส่งอีเมล)',
      user: newUserObj
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * แก้ไขรายละเอียดผู้ใช้งาน:
 * - เฉพาะ Super Admin เท่านั้นที่สามารถแก้ไขรายละเอียดผู้ใช้งานคนอื่นได้
 * - เจ้าของบัญชี (Self) สามารถแก้ไขรายละเอียดเฉพาะของตัวเองได้เท่านั้น
 */
function updateUserDetails(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const actorRole = String(payload.actorRole || '').toLowerCase();
    const actorUserId = String(payload.actorUserId || '');
    const targetUserId = String(payload.userId || '');

    const isSuperAdmin = actorRole === 'super_admin';
    const isSelf = actorUserId && actorUserId === targetUserId;

    if (!isSuperAdmin && !isSelf) {
      return { success: false, message: 'เฉพาะ Super Admin เท่านั้นที่สามารถแก้ไขข้อมูลผู้ใช้งานอื่นได้ (ผู้ใช้งานทั่วไปแก้ไขได้เฉพาะข้อมูลของตนเอง)' };
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
    const sheet = ensureSuperAdminAndSchema(ss, nowStr);
    const data = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === targetUserId) {
        const targetRow = i + 1;
        const currentPass = String(data[i][2] || '');
        const currentRole = String(data[i][5] || 'staff').toLowerCase();
        const currentActive = String(data[i][8] !== undefined ? data[i][8] : 'TRUE');
        const createdAt = String(data[i][9] || nowStr);

        const nextRole = (isSuperAdmin && payload.role && currentRole !== 'super_admin') ? String(payload.role).toLowerCase() : currentRole;
        const nextPass = payload.password ? String(payload.password).trim() : currentPass;

        sheet.getRange(targetRow, 1, 1, 10).setValues([[
          targetUserId,
          String(payload.username || data[i][1]).trim(),
          nextPass,
          String(payload.fullName || data[i][3]).trim(),
          String(payload.department || data[i][4]).trim(),
          nextRole,
          String(payload.position || data[i][6]).trim(),
          String(payload.email || data[i][7]).trim(),
          currentActive,
          createdAt
        ]]);

        return { success: true, message: 'อัปเดตข้อมูลผู้ใช้งานเรียบร้อยแล้ว' };
      }
    }
    return { success: false, message: 'ไม่พบบัญชีผู้ใช้งานที่ต้องการแก้ไข' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * จัดการผู้ใช้งาน (เปลี่ยนสิทธิ์ / ระงับใช้งาน / ลบผู้ใช้งาน) — สงวนสิทธิ์เฉพาะ Super Admin เท่านั้น
 */
function manageUserAction(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const actorRole = String(payload.actorRole || '').toLowerCase();
    if (actorRole !== 'super_admin') {
      return { success: false, message: 'สงวนสิทธิ์เฉพาะ Super Admin เท่านั้นในการแก้ไขสิทธิ์ ระงับ หรือลบผู้ใช้งาน' };
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
    const sheet = ensureSuperAdminAndSchema(ss, nowStr);
    const data = sheet.getDataRange().getValues();

    let targetRow = -1;
    let targetRole = '';
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(payload.userId)) {
        targetRow = i + 1;
        targetRole = String(data[i][5]).toLowerCase();
        break;
      }
    }

    if (targetRow === -1) {
      return { success: false, message: 'ไม่พบบัญชีผู้ใช้งานที่ระบุ' };
    }
    if (targetRole === 'super_admin') {
      return { success: false, message: 'ไม่สามารถลบหรือระงับบัญชี Super Admin ได้' };
    }

    if (payload.action === 'SET_ROLE') {
      sheet.getRange(targetRow, 6).setValue(payload.role);
      return { success: true, message: 'เปลี่ยนสิทธิ์การใช้งานเป็น ' + payload.role.toUpperCase() + ' เรียบร้อยแล้ว' };
    }
    if (payload.action === 'TOGGLE_ACTIVE') {
      sheet.getRange(targetRow, 9).setValue(payload.active ? 'TRUE' : 'FALSE');
      return { success: true, message: payload.active ? 'เปิดใช้งานบัญชีเรียบร้อยแล้ว' : 'ระงับการใช้งานบัญชีเรียบร้อยแล้ว' };
    }
    if (payload.action === 'DELETE_USER') {
      sheet.deleteRow(targetRow);
      return { success: true, message: 'ลบผู้ใช้งานออกจากระบบเรียบร้อยแล้ว' };
    }
    return { success: false, message: 'คำสั่งไม่ถูกต้อง' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * บันทึกรายการหมวดหมู่พัสดุ — สงวนสิทธิ์เฉพาะ Super Admin เท่านั้นในการเพิ่ม/แก้ไข/ลบหมวดหมู่
 */
function saveCategories(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const actorRole = String(payload.actorRole || '').toLowerCase();
    if (actorRole !== 'super_admin') {
      return { success: false, message: 'สงวนสิทธิ์เฉพาะ Super Admin เท่านั้นในการเพิ่ม แก้ไข หรือลบหมวดหมู่พัสดุ' };
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
    let catSheet = ss.getSheetByName(SHEET_NAMES.CATEGORIES);
    if (!catSheet) {
      catSheet = ss.insertSheet(SHEET_NAMES.CATEGORIES);
    }
    catSheet.clearContents();
    catSheet.appendRow(['CategoryName', 'UpdatedAt']);
    catSheet.getRange(1, 1, 1, 2).setFontWeight('bold').setBackground('#555859').setFontColor('#ffd100');

    const categories = Array.isArray(payload.categories) && payload.categories.length > 0
      ? payload.categories
      : DEFAULT_CATEGORIES_LIST;

    const rows = categories.map(function(c) { return [String(c).trim(), nowStr]; });
    catSheet.getRange(2, 1, rows.length, 2).setValues(rows);

    return { success: true, categories: categories, message: 'บันทึกรายการหมวดหมู่พัสดุเรียบร้อยแล้ว' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * ดึงข้อมูลทั้งหมดสำหรับแสดงผลในแอป
 */
function getInitialData() {
  setupDatabase();
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  const userSheet = ss.getSheetByName(SHEET_NAMES.USERS);
  const userRows = userSheet.getDataRange().getValues();
  const users = [];
  for (let i = 1; i < userRows.length; i++) {
    const u = userRows[i];
    if (!u[0]) continue;
    users.push({
      userId: String(u[0]),
      username: String(u[1]),
      password: String(u[2]),
      fullName: String(u[3]),
      department: String(u[4]),
      role: String(u[5]).toLowerCase(),
      position: String(u[6] || ''),
      email: String(u[7] || ''),
      active: String(u[8] !== undefined ? u[8] : 'TRUE').toUpperCase() !== 'FALSE',
      createdAt: String(u[9] || '')
    });
  }

  let categories = DEFAULT_CATEGORIES_LIST.slice();
  const catSheet = ss.getSheetByName(SHEET_NAMES.CATEGORIES);
  if (catSheet) {
    const catRows = catSheet.getDataRange().getValues();
    const loadedCats = [];
    for (let i = 1; i < catRows.length; i++) {
      const cName = String(catRows[i][0] || '').trim();
      if (cName) loadedCats.push(cName);
    }
    if (loadedCats.length > 0) categories = loadedCats;
  }

  const invSheet = ss.getSheetByName(SHEET_NAMES.INVENTORY);
  const invRows = invSheet.getDataRange().getValues();
  const inventory = [];
  for (let i = 1; i < invRows.length; i++) {
    const r = invRows[i];
    if (!r[0]) continue;
    let images = [];
    try {
      images = JSON.parse(r[9] || '[]');
    } catch (e) {
      images = [];
    }
    inventory.push({
      code: String(r[0]),
      name: String(r[1]),
      category: String(r[2]),
      unit: String(r[3]),
      stock: Number(r[4]) || 0,
      minStock: Number(r[5]) || 0,
      price: Number(r[6]) || 0,
      location: String(r[7] || '-'),
      updatedAt: String(r[8] || ''),
      images: Array.isArray(images) ? images.slice(0, 5) : [],
      primaryImageIdx: Number(r[10]) || 0
    });
  }

  const reqSheet = ss.getSheetByName(SHEET_NAMES.REQUISITIONS);
  const reqRows = reqSheet.getDataRange().getValues();
  const requisitions = [];
  for (let i = 1; i < reqRows.length; i++) {
    const r = reqRows[i];
    if (!r[0]) continue;
    let parsedItems = [];
    try {
      parsedItems = JSON.parse(r[7] || '[]');
    } catch (err) {
      parsedItems = [];
    }
    requisitions.push({
      reqId: String(r[0]),
      createdAt: String(r[1]),
      username: String(r[2]),
      requesterName: String(r[3]),
      department: String(r[4]),
      purpose: String(r[5]),
      priority: String(r[6] || 'ปกติ'),
      items: parsedItems,
      totalQty: Number(r[8]) || 0,
      totalValue: Number(r[9]) || 0,
      status: String(r[10] || 'รออนุมัติ'),
      approvedBy: String(r[11] || ''),
      actionAt: String(r[12] || ''),
      adminNote: String(r[13] || '')
    });
  }

  return {
    success: true,
    users: users,
    categories: categories,
    inventory: inventory,
    requisitions: requisitions.reverse()
  };
}

/**
 * บันทึกใบเบิกพัสดุใหม่
 */
function submitRequisition(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const reqSheet = ss.getSheetByName(SHEET_NAMES.REQUISITIONS);
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
    const ymStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyyMM');
    const nextNum = String(reqSheet.getLastRow()).padStart(3, '0');
    const reqId = 'REQ-' + ymStr + '-' + nextNum;

    const items = payload.items || [];
    let totalQty = 0;
    let totalValue = 0;
    items.forEach(function(item) {
      totalQty += Number(item.qty) || 0;
      totalValue += (Number(item.qty) || 0) * (Number(item.price) || 0);
    });

    reqSheet.appendRow([
      reqId,
      nowStr,
      payload.username,
      payload.requesterName,
      payload.department,
      payload.purpose,
      payload.priority || 'ปกติ',
      JSON.stringify(items),
      totalQty,
      totalValue,
      'รออนุมัติ',
      '',
      '',
      ''
    ]);

    return {
      success: true,
      reqId: reqId,
      message: 'ส่งคำขอเบิกพัสดุเลขที่ ' + reqId + ' เรียบร้อยแล้ว'
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * แก้ไขและส่งใบเบิกซ้ำ สำหรับเอกสารที่ถูกตีกลับแก้ไข (User เจ้าของใบเบิกสามารถแก้ไขและส่งซ้ำได้)
 */
function resubmitRequisition(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const reqSheet = ss.getSheetByName(SHEET_NAMES.REQUISITIONS);
    const reqData = reqSheet.getDataRange().getValues();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');

    for (let i = 1; i < reqData.length; i++) {
      if (String(reqData[i][0]) === String(payload.reqId)) {
        const targetRow = i + 1;
        const items = payload.items || [];
        let totalQty = 0;
        let totalValue = 0;
        items.forEach(function(item) {
          totalQty += Number(item.qty) || 0;
          totalValue += (Number(item.qty) || 0) * (Number(item.price) || 0);
        });

        reqSheet.getRange(targetRow, 2).setValue(nowStr);
        reqSheet.getRange(targetRow, 6).setValue(payload.purpose || reqData[i][5]);
        reqSheet.getRange(targetRow, 7).setValue(payload.priority || reqData[i][6]);
        reqSheet.getRange(targetRow, 8).setValue(JSON.stringify(items));
        reqSheet.getRange(targetRow, 9).setValue(totalQty);
        reqSheet.getRange(targetRow, 10).setValue(totalValue);
        reqSheet.getRange(targetRow, 11).setValue('รออนุมัติ');
        reqSheet.getRange(targetRow, 13).setValue(nowStr);
        reqSheet.getRange(targetRow, 14).setValue('ผู้ขอเบิกแก้ไขรายการและส่งคำขอซ้ำเมื่อ ' + nowStr);

        return {
          success: true,
          reqId: payload.reqId,
          message: 'แก้ไขและส่งใบเบิกซ้ำเลขที่ ' + payload.reqId + ' เรียบร้อยแล้ว'
        };
      }
    }
    return { success: false, message: 'ไม่พบใบเบิกพัสดุที่ต้องการแก้ไข' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * อนุมัติ / จ่ายพัสดุ (ตัดสต็อกอัตโนมัติ) / ตีกลับแก้ไข / ไม่อนุมัติใบเบิก (เฉพาะ Super Admin และ Admin)
 */
function updateRequisitionStatus(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const actorRole = String(payload.actorRole || 'admin').toLowerCase();
    if (actorRole !== 'super_admin' && actorRole !== 'admin') {
      return { success: false, message: 'สงวนสิทธิ์เฉพาะ Super Admin และ Admin เท่านั้นในการอนุมัติหรือตีกลับใบเบิก' };
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const reqSheet = ss.getSheetByName(SHEET_NAMES.REQUISITIONS);
    const invSheet = ss.getSheetByName(SHEET_NAMES.INVENTORY);
    const logSheet = ss.getSheetByName(SHEET_NAMES.LOGS);

    const reqData = reqSheet.getDataRange().getValues();
    const invData = invSheet.getDataRange().getValues();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');

    let targetRow = -1;
    let currentStatus = '';
    let reqItems = [];

    for (let i = 1; i < reqData.length; i++) {
      if (String(reqData[i][0]) === String(payload.reqId)) {
        targetRow = i + 1;
        currentStatus = String(reqData[i][10]);
        reqItems = JSON.parse(reqData[i][7] || '[]');
        break;
      }
    }

    if (targetRow === -1) {
      return { success: false, message: 'ไม่พบใบเบิกพัสดุที่ระบุ' };
    }

    if (payload.newStatus === 'จ่ายพัสดุแล้ว' && currentStatus !== 'จ่ายพัสดุแล้ว') {
      for (let j = 0; j < reqItems.length; j++) {
        const reqItem = reqItems[j];
        for (let k = 1; k < invData.length; k++) {
          if (String(invData[k][0]) === String(reqItem.code)) {
            const currentStock = Number(invData[k][4]) || 0;
            if (currentStock < Number(reqItem.qty)) {
              return {
                success: false,
                message: 'พัสดุ "' + reqItem.name + '" มีสต็อกไม่พอ (คงเหลือ ' + currentStock + ' ' + reqItem.unit + ')'
              };
            }
          }
        }
      }

      for (let j = 0; j < reqItems.length; j++) {
        const reqItem = reqItems[j];
        for (let k = 1; k < invData.length; k++) {
          if (String(invData[k][0]) === String(reqItem.code)) {
            const newStock = (Number(invData[k][4]) || 0) - (Number(reqItem.qty) || 0);
            invData[k][4] = newStock;
            invSheet.getRange(k + 1, 5).setValue(newStock);
            invSheet.getRange(k + 1, 9).setValue(nowStr);

            logSheet.appendRow([
              'LOG-' + new Date().getTime(),
              nowStr,
              reqItem.code,
              reqItem.name,
              'เบิกจ่ายพัสดุ',
              -Math.abs(Number(reqItem.qty)),
              newStock,
              payload.adminName || 'Admin',
              payload.reqId
            ]);
          }
        }
      }
    }

    reqSheet.getRange(targetRow, 11).setValue(payload.newStatus);
    reqSheet.getRange(targetRow, 12).setValue(payload.adminName || 'Admin');
    reqSheet.getRange(targetRow, 13).setValue(nowStr);
    reqSheet.getRange(targetRow, 14).setValue(payload.adminNote || '');

    return {
      success: true,
      message: 'อัปเดตสถานะใบเบิก ' + payload.reqId + ' เป็น "' + payload.newStatus + '" เรียบร้อยแล้ว'
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * ลบคำขอเบิกพัสดุออกจากระบบ — สงวนสิทธิ์เฉพาะ Super Admin และ Admin เท่านั้น
 */
function deleteRequisition(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const actorRole = String(payload.actorRole || '').toLowerCase();
    if (actorRole !== 'super_admin' && actorRole !== 'admin') {
      return { success: false, message: 'สงวนสิทธิ์เฉพาะ Super Admin และ Admin เท่านั้นในการลบคำขอเบิกพัสดุ' };
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const reqSheet = ss.getSheetByName(SHEET_NAMES.REQUISITIONS);
    const reqData = reqSheet.getDataRange().getValues();

    for (let i = 1; i < reqData.length; i++) {
      if (String(reqData[i][0]) === String(payload.reqId)) {
        reqSheet.deleteRow(i + 1);
        return { success: true, message: 'ลบคำขอเบิกพัสดุเลขที่ ' + payload.reqId + ' เรียบร้อยแล้ว' };
      }
    }
    return { success: false, message: 'ไม่พบคำขอเบิกพัสดุที่ต้องการลบ' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * เพิ่มรายการพัสดุใหม่ / แก้ไขข้อมูลและรูปภาพ / รับเข้าสต็อก — สงวนสิทธิ์เฉพาะ Super Admin และ Admin เท่านั้น
 */
function saveInventoryItem(itemPayload) {
  const actorRole = String(itemPayload.actorRole || '').toLowerCase();
  const isSuperOrAdmin = actorRole === 'super_admin' || actorRole === 'admin' || String(itemPayload.actorName || '').trim() === 'สมชาย อาบา';
  if (!isSuperOrAdmin) {
    return { success: false, message: 'สงวนสิทธิ์เฉพาะ Super Admin/Admin เท่านั้นในการเพิ่ม แก้ไขรายการพัสดุ และรับเข้าสต็อก' };
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const invSheet = ss.getSheetByName(SHEET_NAMES.INVENTORY);
    const logSheet = ss.getSheetByName(SHEET_NAMES.LOGS);
    const invData = invSheet.getDataRange().getValues();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');

    let targetRow = -1;
    let oldStock = 0;
    for (let i = 1; i < invData.length; i++) {
      if (String(invData[i][0]) === String(itemPayload.code)) {
        targetRow = i + 1;
        oldStock = Number(invData[i][4]) || 0;
        break;
      }
    }

    const images = Array.isArray(itemPayload.images) ? itemPayload.images.slice(0, 5) : [];
    const primaryIdx = Number(itemPayload.primaryImageIdx) || 0;

    const rowValues = [
      itemPayload.code,
      itemPayload.name,
      itemPayload.category,
      itemPayload.unit,
      Number(itemPayload.stock) || 0,
      Number(itemPayload.minStock) || 0,
      Number(itemPayload.price) || 0,
      itemPayload.location || '-',
      nowStr,
      JSON.stringify(images),
      primaryIdx
    ];

    if (targetRow > 0) {
      invSheet.getRange(targetRow, 1, 1, 11).setValues([rowValues]);
      const diff = (Number(itemPayload.stock) || 0) - oldStock;
      if (diff !== 0) {
        logSheet.appendRow([
          'LOG-' + new Date().getTime(),
          nowStr,
          itemPayload.code,
          itemPayload.name,
          diff > 0 ? 'รับเข้า/ปรับเพิ่มสต็อก' : 'ปรับลดสต็อก',
          diff,
          Number(itemPayload.stock) || 0,
          itemPayload.actorName || 'Admin',
          'จัดการคลังพัสดุ'
        ]);
      }
    } else {
      invSheet.appendRow(rowValues);
      logSheet.appendRow([
        'LOG-' + new Date().getTime(),
        nowStr,
        itemPayload.code,
        itemPayload.name,
        'เพิ่มพัสดุใหม่',
        Number(itemPayload.stock) || 0,
        Number(itemPayload.stock) || 0,
        itemPayload.actorName || 'Admin',
        'เพิ่มรายการใหม่'
      ]);
    }

    return { success: true, message: 'บันทึกข้อมูลพัสดุ ' + itemPayload.name + ' เรียบร้อยแล้ว' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * ลบรายการพัสดุออกจากคลัง — สงวนสิทธิ์เฉพาะ Super Admin เท่านั้น (Admin และ Staff ไม่สามารถลบได้)
 */
function deleteInventoryItem(payload) {
  const actorRole = String(payload.actorRole || '').toLowerCase();
  if (actorRole !== 'super_admin' && String(payload.actorName || '').trim() !== 'สมชาย อาบา') {
    return { success: false, message: 'สงวนสิทธิ์เฉพาะ Super Admin เท่านั้นในการลบรายการพัสดุ (Admin และ Staff ไม่สามารถลบได้)' };
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const invSheet = ss.getSheetByName(SHEET_NAMES.INVENTORY);
    const logSheet = ss.getSheetByName(SHEET_NAMES.LOGS);
    const invData = invSheet.getDataRange().getValues();
    const nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');

    for (let i = 1; i < invData.length; i++) {
      if (String(invData[i][0]) === String(payload.code)) {
        const itemName = String(invData[i][1]);
        const oldStock = Number(invData[i][4]) || 0;
        invSheet.deleteRow(i + 1);
        logSheet.appendRow([
          'LOG-' + new Date().getTime(),
          nowStr,
          payload.code,
          itemName,
          'ลบรายการพัสดุ',
          -oldStock,
          0,
          payload.actorName || 'Super Admin',
          'ลบออกจากคลังพัสดุ'
        ]);
        return { success: true, message: 'ลบรายการพัสดุ "' + itemName + '" เรียบร้อยแล้ว' };
      }
    }
    return { success: false, message: 'ไม่พบรหัสพัสดุที่ต้องการลบ' };
  } finally {
    lock.releaseLock();
  }
}
